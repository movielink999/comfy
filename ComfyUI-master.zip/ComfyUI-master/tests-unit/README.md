# Pytest Unit Tests

## Install test dependencies

`pip install -r tests-unit/requirements.txt`

## Run tests
`pytest tests-unit/`
